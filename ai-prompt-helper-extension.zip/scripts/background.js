chrome.runtime.onInstalled.addListener(()=>{
  // Placeholder for future initialization or migrations
});

// Optionally set per-site side panel defaults in future
// chrome.sidePanel.setOptions({ enabled: true, path: 'sidepanel.html' });